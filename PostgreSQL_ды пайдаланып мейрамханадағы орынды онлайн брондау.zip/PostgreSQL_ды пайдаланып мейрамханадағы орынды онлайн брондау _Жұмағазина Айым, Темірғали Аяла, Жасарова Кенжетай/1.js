const restaurants = [ 
  { 
    name: "Өzen Lobby Lounge", 
    image: "1.jpeg", 
    description: "Орташа чек: 20 000 теңге <br> Мекен-жайы: Достык 16 <br> Instagram: @ozenlobby <br> Асхана: Еуропалық, Азиялық <br> ", 
    opisanie: "Сапалы алкогольді сусындар мен джазды білетіндерге Өzen Lobby Lounge ұнайды.Әр жұма сайын қонақтар үшін джаз тобы ойнайды, джаздың шынайы жанкүйерлері үшін репертуар таңдайды, ал мекеменің коктейль философиясы таң қалдырады — мұнда олар хош иістерге негізделген Еуропаның ең жақсы бартендерлерімен құрастырылған." 
  }, 
  { 
    name: "Selfie", 
    image: "2.jpeg", 
    description:"Орташа чек: 25 000 теңге <br> Мекен-жайы: Достық 16 <br> Instagram: @selfievastane <br> Асхана: Еуропалық, Азиялық <br>",
    opisanie: "Ritz Carlton қонақ үйінің 18 қабатындағы панорамалық мейрамхана. Интерьерден бастап ас үйге дейін бәрі қымбат, әдемі көрінеді. Ашық ас үйде автордың ерекше тағамдары дүниеге келеді. Мекемеде ең жақсы аспаздармен бірге гастрономиялық түскі ас жиі болады." 
  }, 
  { 
      name: "Mökki", 
      image: "3.jpeg", 
      description: "Орташа чек: 15 000 теңге <br> Мекен-жайы: Достық 16 <br> Instagram: @mokkirestaurant <br> Асхана: Еуропалық, Итальяндық <br>", 
      opisanie: "Сізге ең сәнді көйлек киюдің қажеті жоқ мейрамхана - мейрамхананың атауы швед тілінен аударғанда «cаяжай» дегенді білдіреді және мұнда өте жылы, жайлы атмосфера бар. Мұндағы ас мәзірі аптасына 2 рет жаңартылып отырады және әртүрлі халықаралық тағамдарды жеуге болады. Мейрамхана сол жағалаудың әдемі көрінісін ұсынады." 
    },     
    { 
      name: "Salone del Gusto", 
      image: "4.jpeg", 
      description: "Орташа чек: 15 000 теңге <br> Мекен-жайы: Қабанбай батыр 15а <br> Instagram: @salonedelgusto_astana <br> Асхана: Итальяндық <br>", 
      opisanie: "Рояль, сигаралар, қымбат шарап - мекеменің сән-салтанатына күмән жоқ. Бұл уақыт өткізуге ыңғайлы орын - жанды музыка бар, интерьер заманауи стильде талғампаз классикада жасалған, ал ас үй ерекше тағамдармен қуантады." 
    }, 
    { 
      name: "Line Brew Reserve", 
      image: "5.jpeg", 
      description: "Орташа чек: 15 000 теңге <br> Мекен-жайы: Қадырғали Жалайыри 4 <br> Instagram: @linebrewreserve <br> Асхана: Еуропалық, Шығыс <br>", 
      opisanie: "Мекеменің интерьеріне қарап, сіз бірден көп ақша кетіруге тура келетінін елестетесіз-қымбат және ғарыштық нәрсе. Мұнда келген кезде сіз тағамдарды көріп, не таңдарыңызды білмей қаласыз. Тек стейктердің 9 түрі бар. Залдың ортасындағы сахна жанды музыкамен...перде." 
    }, 
    { 
      name: "La Rivière", 
      image: "6.jpeg", 
      description: "Орташа чек: 18 000 теңге <br> Мекен-жайы: Қабанбай батыр 1 <br> Instagram: @lariviereastana <br> Асхана: Земноморская, Итальяндық <br>", 
      opisanie: "Өзенге қарайтын Жерорта теңізі тамағын жеу жақсы естіледі. La Rivière - дәл жағалауда орналасқан сәнді St. Regis Astana қонақүйіндегі керемет мейрамхана. Бірақ мекемедегі ең жақсы нәрсе - жексенбілік таңғы ас. Олар мұнда үнемі өткізіледі." 
    },  

    { 
      name: "Felice", 
      image: "7.jpeg", 
      description: "Орташа чек: 15 000 теңге <br> Мекен-жайы: Сарыарқа 1 <br> Instagram: @felice_astana <br> Асхана: Итальяндық <br>", 
      opisanie: "Дресс-коды бар мейрамхана, онда Мишлен жұлдызды аспаз сізге итальяндық тағам дайындайды. Интерьер өзінің сән-салтанатымен таң қалдырады - сәндік гүлдер, еден шамдары, шамдар, ойылған айналар және тіпті алтын жиегі бар ыдыс-аяқтар барлық жерде. Ең қызығы, мұнда сіз ұшақта ұшуға арналған тағамға тапсырыс бере аласыз, өйткені мейрамхана халықаралық әуежай ішінде жеткізуді ұсынады. " 
    },  
    { 
      name: "Qazaq Gourmet", 
      image: "8.jpeg", 
      description: "Орташа чек: 15 000 теңге <br> Мекен-жайы: Мәңгілік Ел 29 <br> Instagram: @qazaq.Gourmet <br> Асхана: Қазақ <br>", 
      opisanie: "Қазақтың жоғары асханасы – мұнда ерекше тәсілмен дәстүрлі ұлттық тағамдар дайындалады. Сіз сондай-ақ әдеттен тыс, бірақ таныс нәрсені көре аласыз. Интерьер ұлттық нақышта жасалған - көптеген ою-өрнектер. ауыр мата және ағаш." 
    },  
    { 
      name: "Garo", 
      image: "9.jpeg", 
      description: "Орташа чек: 15 000 теңге <br> Мекен-жайы: Достық 16 <br> Instagram: @giro.talon галереясы <br> Асхана: Еуропалық, Итальяндық <br>", 
      opisanie: "Мұнда кейбір тағамдарды дайындау - бұл бүкіл шоу. Мысалы, аспаз стейкті шығарып, оны дайын күйге келтіреді. Мейрамханада сондай-ақ аспазшыдан мәзір бар. Интерьерде көптеген жабық өсімдіктер, жарық және ағаш бар." 
    },  
    { 
      name: "Brunello", 
      image: "10.jpeg", 
      description: "Орташа чек: 10 000 теңге <br> Мекен-жайы: Мәңгілік Ел даңғылы, 47 <br> Instagram: @Brunello.lounge <br> Асхана: Еуропалық <br> ", 
      opisanie: "Әрбір тағам дәм әлеміне саяхат болатын талғампаз тағамдардан рахат алыңыз. Ең жарқын және есте қаларлық демалыс күндері тек Brunello lounge-да" 
    },  
    { 
      name: "SAHARA", 
      image: "11.jpeg", 
      description: "Орташа чек: 8 000 теңге <br> Мекен-жайы: 25-ші көше, 9 <Br> Instagram: @Sahara.rest <br> Асхана: Еуропалық, Азиялық <br> ", 
      opisanie: "Оларда кез келген дәм мен түске арналған бар сусындарының үлкен ассортименті, сондай-ақ әртүрлі эстетикалық таңғы астардың үлкен таңдауы бар." 
    },  
    { 
      name: "Baoli", 
      image: "12.jpeg", 
      description: "Орташа чек: 5 000 теңге <br> Мекен-жайы: Түркістан көшесі, 16 <br> Instagram: @baoliastana <br> Асхана: Итальян, Жапон <br> ", 
      opisanie: "Кездесулер мен мерекелер үшін ең жақсы орын. BAOLI - тәжірибелі бармендер дайындаған коктейльдердің кең таңдауын тамашалай алатын орын" 
    } 
]; 
 
document.addEventListener("DOMContentLoaded", function(event) { 
  const restaurantContainer = document.getElementById('restaurantContainer'); 
 
  restaurants.forEach(restaurant => { 
    const card = document.createElement('div'); 
    card.classList.add('card'); 
    card.innerHTML = ` 
      <img src="${restaurant.image}" alt="${restaurant.name}"> 
      <h2>${restaurant.name}</h2> 
      <p>${restaurant.description}</p> 
      <button onclick="showRestaurantInfo('${restaurant.name}', '${restaurant.image}', '${restaurant.opisanie}');">Толығырақ</button> 
      <button onclick="goToNextPage()">Брондау</button> 
    `; 
    restaurantContainer.appendChild(card); 
  }); 
}); 
 
function showRestaurantInfo(name, image, description, opisanie) { 
  const modal = document.getElementById('myModal'); 
  const modalTitle = document.getElementById('modalTitle'); 
  const modalImage = document.getElementById('modalImage'); 
  const modalDescription = document.getElementById('modalDescription'); 
  const modalOpisanie = document.getElementById('modalOpisanie'); 
 
  modal.style.display = 'block'; 
  modalTitle.textContent = name; 
  modalImage.src = image; 
  modalDescription.textContent = description; 
  modalOpisanie.textContent = opisanie; 
} 
 
function goToNextPage() { 
  window.location.href = '3.html'; 
} 
 
function closeModal() { 
  const modal = document.getElementById('myModal'); 
  modal.style.display = 'none'; 
}