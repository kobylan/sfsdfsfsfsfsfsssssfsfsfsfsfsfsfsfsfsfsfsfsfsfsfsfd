const express = require('express');
const { Pool } = require('pg');

const app = express();
const port = 3001; // Change the port to 3001 or any other available port

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'reserve',
  password: '4296',
  port: 5432,
});

app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/2.html');
});

app.post('/submit', async (req, res) => {
  try {
    const { name, restaurant, datepicker, phoneNumber, timeInput, guests } = req.body;

    const result = await pool.query(
      'INSERT INTO reservations (name, restaurant, reservation_date, phone_number, reservation_time, guests) VALUES ($1, $2, $3, $4, $5, $6)',
      [name, restaurant, datepicker, phoneNumber, timeInput, guests]
    );

    console.log('Data inserted successfully:', result.rows);

    // Send a styled message with a button to go back to the main page
    res.send(`
      <div style="text-align: center; font-size: 24px; color: pink;">
        <p style="font-size: 36px;">Администратор жақын арада сізге хабарласады!</p>
        <div style="background-color: pink; padding: 10px; display: inline-block; border-radius: 10px;">
          <form action="/" method="get">
            <button type="submit" style="background-color: white; padding: 10px; font-size: 20px; border: none; border-radius: 5px; cursor: pointer;">Басты бетке өту</button>
          </form>
        </div>
      </div>
    `);
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
